/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 gameBackground gameBackground.png 
 * Time-stamp: Saturday 11/16/2019, 04:06:12
 * 
 * Image Information
 * -----------------
 * gameBackground.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMEBACKGROUND_H
#define GAMEBACKGROUND_H

extern const unsigned short gameBackground[38400];
#define GAMEBACKGROUND_SIZE 76800
#define GAMEBACKGROUND_LENGTH 38400
#define GAMEBACKGROUND_WIDTH 240
#define GAMEBACKGROUND_HEIGHT 160

#endif

