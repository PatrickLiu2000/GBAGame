/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 startScreen startBackground.png 
 * Time-stamp: Friday 11/15/2019, 21:49:36
 * 
 * Image Information
 * -----------------
 * startBackground.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTSCREEN_H
#define STARTSCREEN_H

extern const unsigned short startBackground[38400];
#define STARTBACKGROUND_SIZE 76800
#define STARTBACKGROUND_LENGTH 38400
#define STARTBACKGROUND_WIDTH 240
#define STARTBACKGROUND_HEIGHT 160

#endif

