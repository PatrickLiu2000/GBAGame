Breakout Game
-----------------------------
Objective: destroy all rectangles using the ball, given 5 lives
Controls:
Left - move paddle left
right - move paddle right
select - reset to start screen
a button - used to advance between screens